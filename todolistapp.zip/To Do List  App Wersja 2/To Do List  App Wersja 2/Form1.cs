﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace To_Do_List__App_Wersja_2
{
    public partial class ToDoList : Form
    {
        TaskManager taskManager = new TaskManager();
        string filePath = "tasks.json";
        bool isEditing = false;
        public ToDoList()
        {
            InitializeComponent();
        }

        
        private void ToDoList_Load(object sender, EventArgs e)
        {
            taskManager.Load(filePath);
            UpdateGrid();
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            titleTextBox.Text = "";
            descriptionTextBox.Text = "";
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            if (toDoListView.CurrentCell == null || toDoListView.CurrentCell.RowIndex < 0)
                return;


            isEditing = true;
            var selectedTask = taskManager.Tasks[toDoListView.CurrentCell.RowIndex];
            titleTextBox.Text = selectedTask.Title;
            descriptionTextBox.Text = selectedTask.Description;
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (toDoListView.CurrentCell != null)
                {
                    taskManager.Tasks.RemoveAt(toDoListView.CurrentCell.RowIndex);
                    UpdateGrid();
                    taskManager.Save(filePath);
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                var selectedTask = taskManager.Tasks[toDoListView.CurrentCell.RowIndex];
                selectedTask.Title = titleTextBox.Text;
                selectedTask.Description = descriptionTextBox.Text;
            }
            else
            {
                taskManager.Tasks.Add(new TaskItem
                {
                    Title = titleTextBox.Text,
                    Description = descriptionTextBox.Text,
                    Completed = false
                });

            }

            // Wyczysc pola tekstowe
            titleTextBox.Text = "";
            descriptionTextBox.Text = "";
            isEditing = false;

            // Odswiez tabele
            UpdateGrid();
            taskManager.Save(filePath);
        }
           
        
            private void UpdateGrid()
        {
            toDoListView.DataSource = null;
            toDoListView.DataSource = taskManager.Tasks
                .Select(t => new { t.Title, t.Description, t.Completed })
                .ToList();
        
        }

        private void ToDoList_FormClosing(object sender, FormClosingEventArgs e)
        {
            taskManager.Save(filePath);
        }

        private void completeButton_Click(object sender, EventArgs e)
        {
            if (toDoListView.CurrentCell != null)
            {
                var task= taskManager.Tasks[toDoListView.CurrentCell.RowIndex];
                task.Completed = true;
                UpdateGrid();
                taskManager.Save(filePath);
            }
        }
    }
}

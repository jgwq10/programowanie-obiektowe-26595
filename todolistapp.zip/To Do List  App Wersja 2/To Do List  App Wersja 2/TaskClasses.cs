﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace To_Do_List__App_Wersja_2
{
    // Interfejs do zapisu/odczytu
    interface ISaveable
    {
        void Save(string path);
        void Load(string path);
    }

    // Klasa abstrakcyjna
    public abstract class TaskBase
    {
        public string Title { get; set; }
        public string Description { get; set; }

        public abstract string Display();
    }

    // Podstawowy task
    public class TaskItem : TaskBase
    {
        // Hermetyzacja
        private bool _completed;
        public bool Completed
        {
            get { return _completed; }
            set { _completed = value; }
        }

        public override string Display()
        {
            return $"{Title} - {Description} - Completed: {Completed}";
        }
    }

    // Dziedziczenie + Polimorfizm
    public class UrgentTask : TaskItem
    {
        public override string Display()
        {
            return $"Urgent: {base.Display()}";
        }
    }
}

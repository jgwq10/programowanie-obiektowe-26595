﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace To_Do_List__App_Wersja_2
{
    public class TaskManager : ISaveable
    {
        public List<TaskItem> Tasks { get; set; } = new List<TaskItem>();

        public void Save(string path)
        {
            try
            {
                string json = JsonSerializer.Serialize(Tasks, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(path, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Błąd przy zapisie: " + ex.Message);
            }
        }

        public void Load(string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    string json = File.ReadAllText(path);
                    Tasks = JsonSerializer.Deserialize<List<TaskItem>>(json);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Błąd przy odczycie: " + ex.Message);
            }
        }
    }
}

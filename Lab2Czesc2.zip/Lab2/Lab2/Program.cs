﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Lab2.Models;

namespace Lab2
{
    internal class Program
    {
        static string filePath = "data.json";
        static List<VehicleData> vehicleList = new List<VehicleData>();

        static void Main(string[] args)
        {
            LoadData();

            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("Wybierz opcję z menu:");
                Console.WriteLine("1. Lista pojazdów");
                Console.WriteLine("2. Dodaj pojazd");
                Console.WriteLine("3. Usuń pojazd");
                Console.WriteLine("0. Exit");
                Console.Write("> ");

                int.TryParse(Console.ReadLine(), out choice);
                Console.WriteLine();

                switch (choice)
                {
                    case 1:
                        ShowVehicles();
                        break;
                    case 2:
                        AddVehicle();
                        break;
                    case 3:
                        RemoveVehicle();
                        break;
                    case 0:
                        SaveData();
                        Console.WriteLine("Zamykam program...");
                        break;
                    default:
                        Console.WriteLine("Nieprawidłowa opcja!");
                        break;
                }

                if (choice != 0)
                {
                    Console.WriteLine("\nNaciśnij dowolny klawisz, aby kontynuować...");
                    Console.ReadKey();
                }

            } while (choice != 0);
        }

        // ---------------- FUNKCJE MENU ----------------

        static void ShowVehicles()
        {
            Console.WriteLine("Lista pojazdów:");
            if (vehicleList.Count == 0)
            {
                Console.WriteLine("Brak pojazdów w bazie.");
                return;
            }

            foreach (var v in vehicleList)
            {
                Console.WriteLine($"Model: {v.Model}, Rok: {v.Year}");
            }
        }

        static void AddVehicle()
        {
            Console.Write("Podaj model: ");
            string model = Console.ReadLine();

            Console.Write("Podaj rok: ");
            int.TryParse(Console.ReadLine(), out int year);

            vehicleList.Add(new VehicleData { Model = model, Year = year });
            SaveData();
            Console.WriteLine("✅ Pojazd został dodany.");
        }

        static void RemoveVehicle()
        {
            Console.Write("Podaj model pojazdu do usunięcia: ");
            string model = Console.ReadLine();

            var toRemove = vehicleList.FirstOrDefault(v => v.Model.Equals(model, StringComparison.OrdinalIgnoreCase));

            if (toRemove != null)
            {
                vehicleList.Remove(toRemove);
                SaveData();
                Console.WriteLine("❌ Pojazd został usunięty.");
            }
            else
            {
                Console.WriteLine("Nie znaleziono takiego pojazdu.");
            }
        }

        // ---------------- OBSŁUGA PLIKU JSON ----------------

        static void LoadData()
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                var data = JsonSerializer.Deserialize<List<VehicleData>>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
                if (data != null)
                    vehicleList = data;
            }
        }

        static void SaveData()
        {
            string json = JsonSerializer.Serialize(vehicleList, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }
    }

    // 🔹 Klasa pomocnicza do danych JSON
    public class VehicleData
    {
        public string Model { get; set; }
        public int Year { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab2.Models
{
    public class Bike : Vehicle
    {
        public Bike(string model, int year) : base(model, year)
        {
        }

        public override void ShowInfo()
        {
            base.ShowInfo();
        }
    }
}

﻿using System;

namespace Lab2.Models
{
    public class Car : Vehicle
    {
        public Car(string model, int year) : base(model, year) { }
    }
}

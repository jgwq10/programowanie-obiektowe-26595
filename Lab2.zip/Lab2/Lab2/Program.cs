﻿using System;
using System.IO;
using System.Text.Json;
using Lab2.Models;

namespace Lab2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 🔹 Wczytanie zawartości pliku JSON
            string json = File.ReadAllText("data.json");

            // 🔹 Deserializacja (konwersja JSON -> obiekt)
            var data = JsonSerializer.Deserialize<VehicleData>(json);

            // 🔹 Utworzenie obiektu Car z danych
            Car carFromFile = new Car(data.Model, data.Year);

            // 🔹 Wyświetlenie danych
            carFromFile.ShowInfo("Dane z pliku JSON:");

            Console.ReadKey();
        }
    }

    // 🔹 Klasa pomocnicza do odczytu danych z JSON
    public class VehicleData
    {
        public string Model { get; set; }
        public int Year { get; set; }
    }
}
